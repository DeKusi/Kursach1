from django.apps import AppConfig


class NewappConfig(AppConfig):
    name = 'newApp'
