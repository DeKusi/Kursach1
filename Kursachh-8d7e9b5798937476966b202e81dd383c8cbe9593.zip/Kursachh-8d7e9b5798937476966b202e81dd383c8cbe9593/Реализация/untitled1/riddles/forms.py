from django.forms import ModelForm
from .models import *


class PlaneForm(ModelForm):
    class Meta:
        model = plane
        exclude = [""]
