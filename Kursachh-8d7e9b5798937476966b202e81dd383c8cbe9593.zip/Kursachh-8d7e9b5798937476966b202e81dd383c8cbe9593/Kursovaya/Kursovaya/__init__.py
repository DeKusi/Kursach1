"""
Package for Kursovaya.
"""
